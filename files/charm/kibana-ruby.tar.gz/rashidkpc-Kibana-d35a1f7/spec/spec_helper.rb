$: << File.join(File.dirname(__FILE__), "..")
